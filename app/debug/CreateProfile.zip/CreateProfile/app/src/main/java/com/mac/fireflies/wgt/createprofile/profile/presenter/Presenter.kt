package com.mac.fireflies.wgt.createprofile.profile.presenter

class Presenter {
    fun action(proper: Int) {

    }
}