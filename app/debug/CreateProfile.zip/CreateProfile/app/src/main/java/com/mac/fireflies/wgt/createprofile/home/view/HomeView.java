package com.mac.fireflies.wgt.createprofile.home.view;

import com.mac.fireflies.wgt.createprofile.core.BaseView;

/**
 * Created by Alestar on 2/1/2018.
 */

public interface HomeView extends BaseView {

    void launchProfile();

    void login();

    void logout();

    void launchLogin();
}
