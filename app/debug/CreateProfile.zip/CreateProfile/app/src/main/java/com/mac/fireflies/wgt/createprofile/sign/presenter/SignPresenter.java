package com.mac.fireflies.wgt.createprofile.sign.presenter;


import com.mac.fireflies.wgt.createprofile.core.BasePresenter;
import com.mac.fireflies.wgt.createprofile.sign.view.SignView;

public interface SignPresenter extends BasePresenter<SignView> {
}
