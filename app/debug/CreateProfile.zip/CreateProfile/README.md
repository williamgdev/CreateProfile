# CreateProfile
Create a profile and take a picture with your camera.
The backend is integrated with Firebase (Auth, RealTimeDatabase and Storage).
